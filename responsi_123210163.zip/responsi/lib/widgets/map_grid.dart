import 'package:flutter/material.dart';
import '../models/maps.dart';

class MapGrid extends StatelessWidget {
  final List<GameMap> maps;

  MapGrid({required this.maps});

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
      ),
      itemCount: maps.length,
      itemBuilder: (context, index) {
        final gameMap = maps[index];
        return GestureDetector(
          onTap: () {
            Navigator.pushNamed(
              context,
              '/mapDetail',
              arguments: gameMap,
            );
          },
          child: Card(
            child: Column(
              children: [
                Image.network(gameMap.splash),
                Text(gameMap.displayName),
              ],
            ),
          ),
        );
      },
    );
  }
}
