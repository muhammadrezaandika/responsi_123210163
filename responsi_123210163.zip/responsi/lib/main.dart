import 'package:flutter/material.dart';
import 'screens/home_screen.dart';
import 'screens/agent_list_screen.dart';
import 'screens/map_list_screen.dart';
import 'screens/agent_detail_screen.dart';
import 'screens/map_detail_screen.dart';

void main() {
  runApp(ValorantWikiApp());
}

class ValorantWikiApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Valorant Wiki',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.red,
      ),
      initialRoute: '/',
      routes: {
        '/': (context) => HomeScreen(),
        '/agents': (context) => AgentListScreen(),
        '/maps': (context) => MapListScreen(),
        '/agentDetail': (context) => AgentDetailScreen(),
        '/mapDetail': (context) => MapDetailScreen(),
      },
    );
  }
}
