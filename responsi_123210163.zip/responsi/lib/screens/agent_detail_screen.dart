import 'package:flutter/material.dart';
import '../models/agent.dart';

class AgentDetailScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final Agent agent = ModalRoute.of(context)!.settings.arguments as Agent;

    return Scaffold(
      appBar: AppBar(
        title: Text(agent.displayName),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Image.network(agent.displayIcon),
            SizedBox(height: 8),
            Text(agent.displayName, style: TextStyle(fontSize: 24)),
            SizedBox(height: 8),
            Text(agent.description),
          ],
        ),
      ),
    );
  }
}
