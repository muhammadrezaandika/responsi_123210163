import 'package:flutter/material.dart';
import '../services/api_service.dart';
import '../models/agent.dart';

class AgentListScreen extends StatelessWidget {
  final ApiService apiService = ApiService();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Agents'),
      ),
      body: FutureBuilder<List<Agent>>(
        future: apiService.fetchAgents(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          } else {
            return _buildAgentList(snapshot.data!);
          }
        },
      ),
    );
  }

  Widget _buildAgentList(List<Agent> agents) {
    return ListView.builder(
      itemCount: agents.length,
      itemBuilder: (context, index) {
        final agent = agents[index];
        return GestureDetector(
          onTap: () {
            Navigator.pushNamed(
              context,
              '/agentDetail',
              arguments: agent,
            );
          },
          child: Card(
            color: Colors.red, // Set warna latar belakang menjadi merah
            elevation: 4,
            margin: EdgeInsets.all(8),
            child: Padding(
              padding: EdgeInsets.all(8),
              child: Row(
                children: [
                  // Icon agent di sebelah kiri
                  CircleAvatar(
                    backgroundImage: NetworkImage(agent.displayIcon),
                    backgroundColor: Colors.white, // Set warna latar belakang menjadi putih
                    radius: 40,
                  ),
                  SizedBox(width: 16),
                  // Informasi agent di sebelah kanan
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          agent.displayName,
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            color: Colors.white, // Set warna teks menjadi putih
                          ),
                        ),
                        SizedBox(height: 4),
                        Text(
                          agent.description,
                          style: TextStyle(
                            fontSize: 14,
                            color: Colors.white, // Set warna teks menjadi putih
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
